from setuptools import setup

setup(

	name="paquetecalculos",
	version="1.0",
	description="Paquete de redondeo y potencia",
	author="Ing. José Gómez",
	author_email="jose_1gomez@hotmail.com",
	url="www.technosystems.com",
	packages=["calculos", "calculos.redondeo_potencia"]
	)